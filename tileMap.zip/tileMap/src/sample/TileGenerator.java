package sample;

import javafx.scene.canvas.GraphicsContext;

import java.awt.*;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.FileInputStream;

public class TileGenerator {

    int [] terrain = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,44,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,0,44,0,0,0,0,0,0,0,0,
            0,0,0,0,0,44,0,0,0,0,0,44,0,0,0,0,0,0,0,0,
            0,0,0,0,44,44,0,0,0,0,0,44,0,0,0,0,44,0,0,0,
            44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,
            44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44};

    int level_width;
    int level_height;
    int tile_width;
    int tile_height;
    Color red = new Color(240,248,255);

    int tileMapImgHeight;
    int tileMapImageWidth;
    public TileGenerator(int level_width, int level_height, int tile_width,int tile_height,int tileMapImgHeight, int tileMapImageWidth) {
        this.level_width = level_width;
        this.level_height = level_height;
        this.tile_width = tile_width;
        this.tile_height = tile_height;
        this.tileMapImgHeight = tileMapImgHeight;
        this.tileMapImageWidth = tileMapImageWidth;
    }

    public void draw(GraphicsContext gc) {
        //Disegno l'acqua
        for (int i = 0; i < this.terrain.length; i++) {
            //Ottengo le coordinate sulla canvas
            int dx = (i % this.level_width) * 32;
            int dy = (int)Math.floor(i / this.level_height) * 32;
            int tile = this.terrain[i];

            //Ottengo le coordinate sulla tilemap
            int sx = ((tile  % (this.tileMapImageWidth/32))-1) * 32; //Devo fare -1 perchè il primo tile è il n°1
            int sy = (int)Math.floor(tile / (this.tileMapImgHeight/32)) * 32;


            if (this.terrain[i] != 0) {
                //gc.drawImage(this.tileMapImage, sx, sy, this.tile_width, this.tile_height, dx, dy, this.tile_width, this.tile_height);
                gc.fillRect(dx, dy, this.tile_width, this.tile_height);
                
            }
        }
    }
}




